---
title: "А вдруг анестезия не подействует?"
doc_id: "faq-anesthesia-effectiveness"
doc_type: "safety"
topic: "safety"
verbatim: false
empathy_enabled: true
empathy_tag: "fear_pain"
aliases:
  - "анестезия не подействует"
  - "боюсь что анестезия не возьмет"
  - "обезболивание не работает"
  - "не берет заморозка"
  - "страх анестезии"
preferred_format: ["detailed","bullets"]
cta_action: "consultation"
cta_text: "Обсудить варианты обезболивания"
updated: "2025-09-03"
---

## Анастезия
- Никакой «заморозки» на пол-лица и потери контроля — только прицельное обезболивание  
- Врач всегда убеждается, что вы не чувствуете боли, прежде чем начать  
- Подбираем вид анестезии индивидуально

